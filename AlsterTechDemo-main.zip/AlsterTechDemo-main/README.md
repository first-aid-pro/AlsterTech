https://first-aid-pro.github.io/AlsterTechDemo/

some example sites:

https://www.ngw-shop.de/

https://goethegymnasium-weimar.de/schulelerfirma/schulerfirma-produkte

https://shops.schul.ag

Produkte auf unsere Angebote ändern

Kopfhörer
, 3D Modelle Volumen berechnen
, Individuelles
, Spektrometer
, Linsen


TODO:

- warenkorb entfernen
- "in den Warenkorb" Knöpfe entfernen
- Message bei `Produkten` "Bitte schreibt uns per Email, um ein Produkt zu erstellen"
- `Anmeldung` entfernen
- `Kontakt` mit `mailto` command, we can specify subject` see:[https://stackoverflow.com/questions/4782068/can-i-set-subject-content-of-email-using-mailto]
- `Home` Seite mit was wir sind, was wir anbieten; bild von uns
